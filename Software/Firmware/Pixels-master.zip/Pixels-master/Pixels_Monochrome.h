/*
 * Pixels. Graphics library for TFT displays.
 *
 * Copyright (C) 2012-2013  Igor Repinetski
 *
 * The code is written in C/C++ for Arduino and can be easily ported to any microcontroller by rewritting the low level pin access functions.
 *
 * Text output methods of the library rely on Pixelmeister's font data format. See: http://pd4ml.com/pixelmeister
 *
 * This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/3.0/
 *
 * This library includes some code portions and algoritmic ideas derived from works of
 * - Andreas Schiffler -- aschiffler at ferzkopp dot net (SDL_gfx Project)
 * - K. Townsend http://microBuilder.eu (lpc1343codebase Project)
 */

/*
 * The include optimizes Pixels library for one bit color (monochrome) output
 */

#ifdef PIXELS_MAIN
#error Pixels_Monochrome.h must be included before any Pixels***.h
#endif

#ifndef PIXELS_MONOCHROME_H
#define PIXELS_MONOCHROME_H

#define DISABLE_ANTIALIASING 1

// TODO add RGB() redefinition

#endif
